export interface Client {
  id: number;
  name: string;
  contact: string;
  status: string;
  channel: string;
  transaction: string;
  antiquity: string;
}

